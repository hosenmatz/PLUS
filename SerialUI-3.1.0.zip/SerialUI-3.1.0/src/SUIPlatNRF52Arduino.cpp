/*
 * SUIPlatNRF52Arduino.cpp
 *
 *  Created on: Oct 13, 2018
 *      Author: Pat Deegan
 *
 *  SUIPlatNRF52Arduino is part of the SerialUI project.
 *  Copyright (C) 2018-2019 Pat Deegan, psychogenic.com
 */


#include "includes/SerialUIPlatform.h"

#ifdef SERIALUI_PLATFORM_NRF52

// BLESerial SUIBLESerialDev = BLESerial();

#endif

