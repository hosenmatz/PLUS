/*
 * Menu.cpp
 *
 *  Created on: May 25, 2018
 *      Author: Pat Deegan
 *
 *  Menu is part of the SerialUI project.
 *  Copyright (C) 2018-2019 Pat Deegan, psychogenic.com
 */

#include "includes/Menu.h"

namespace SerialUI {
namespace Menu {

Menu::Menu() {
	// TODO Auto-generated constructor stub

}

Menu::~Menu() {
	// TODO Auto-generated destructor stub
}

} /* namespace Menu */
} /* namespace SerialUI */
