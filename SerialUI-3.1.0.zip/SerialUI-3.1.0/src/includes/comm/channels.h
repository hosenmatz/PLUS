/*
 * channels.h
 *
 *  Created on: May 27, 2018
 *      Author: Pat Deegan
 *
 *  channels is part of the SerialUI project.
 *  Copyright (C) 2018-2019 Pat Deegan, psychogenic.com
 */

#ifndef SERIALUI_SRC_INCLUDES_COMM_CHANNELS_H_
#define SERIALUI_SRC_INCLUDES_COMM_CHANNELS_H_


#include "CommChannelArdStd.h"


#endif /* SERIALUI_SRC_INCLUDES_COMM_CHANNELS_H_ */
