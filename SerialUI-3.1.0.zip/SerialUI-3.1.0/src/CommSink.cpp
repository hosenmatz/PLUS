/*
 * CommSink.cpp
 *
 *  Created on: May 25, 2018
 *      Author: Pat Deegan
 *
 *  CommSink is part of the SerialUI project.
 *  Copyright (C) 2018-2019 Pat Deegan, psychogenic.com
 */

#include "includes/comm/CommSink.h"

namespace SerialUI {
namespace Comm {


} /* namespace Comm */
} /* namespace SerialUI */
